# Cricket Hub Free Demo

1. Open `index.html` in a browser to preview the website.
2. To publish it free with GitHub Pages:
   - Create a GitHub repository.
   - Upload `index.html` and `style.css`.
   - Open Settings -> Pages.
   - Choose the `main` branch and root folder.
   - Save.
3. GitHub will provide a free `github.io` website address.

This demo uses sample cricket data and does not provide betting or wagering functionality.
